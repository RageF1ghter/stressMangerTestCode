# Fitbit Application Code

# Instructions 
1. Navigate to [Fitbit Studio](https://studio.fitbit.com/) and login.
2. Create a new project, name it Stress Manager and select blank project
3. Upload code from this directory to the project root inside fitbit studio
